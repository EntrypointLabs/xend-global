import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `configAuthority` and `rentPayer` before sending it.
 */
export declare function changeThresholdAsAuthority({ blockhash, settingsPda, settingsAuthority, rentPayer, newThreshold, memo, programId, }: {
    blockhash: string;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    rentPayer: PublicKey;
    newThreshold: number;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
