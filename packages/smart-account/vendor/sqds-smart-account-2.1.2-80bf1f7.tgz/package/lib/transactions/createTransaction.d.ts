import { AddressLookupTableAccount, PublicKey, TransactionMessage, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `creator`, `rentPayer` and `feePayer` before sending it.
 */
export declare function createTransaction({ blockhash, feePayer, settingsPda, transactionIndex, creator, rentPayer, accountIndex, ephemeralSigners, transactionMessage, addressLookupTableAccounts, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    /** Member of the multisig that is creating the transaction. */
    creator: PublicKey;
    /** Payer for the transaction account rent. If not provided, `creator` is used. */
    rentPayer?: PublicKey;
    accountIndex: number;
    /** Number of additional signing PDAs required by the transaction. */
    ephemeralSigners: number;
    /** Transaction message to wrap into a multisig transaction. */
    transactionMessage: TransactionMessage;
    /** `AddressLookupTableAccount`s referenced in `transaction_message`. */
    addressLookupTableAccounts?: AddressLookupTableAccount[];
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
