import { AccountMeta, PublicKey, VersionedTransaction } from "@solana/web3.js";
import { SmartAccountSigner } from "../generated";
/**
 * Returns unsigned `VersionedTransaction` that needs to be signed by `creator` and `createKey` before sending it.
 */
export declare function createSmartAccount({ blockhash, treasury, settingsAuthority, creator, settings, threshold, signers, timeLock, rentCollector, memo, programId, remainingAccounts, }: {
    blockhash: string;
    treasury: PublicKey;
    creator: PublicKey;
    settings?: PublicKey;
    settingsAuthority: PublicKey | null;
    threshold: number;
    signers: SmartAccountSigner[];
    timeLock: number;
    rentCollector: PublicKey | null;
    memo?: string;
    programId?: PublicKey;
    remainingAccounts?: AccountMeta[];
}): VersionedTransaction;
