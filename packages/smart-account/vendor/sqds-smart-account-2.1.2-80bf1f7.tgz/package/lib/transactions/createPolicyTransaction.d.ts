import { PublicKey, VersionedTransaction } from "@solana/web3.js";
import { PolicyPayload } from "../generated";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `creator`, `rentPayer` and `feePayer` before sending it.
 */
export declare function createPolicyTransaction({ blockhash, feePayer, policy, transactionIndex, creator, rentPayer, accountIndex, policyPayload, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    policy: PublicKey;
    transactionIndex: bigint;
    /** Member of the multisig that is creating the transaction. */
    creator: PublicKey;
    /** Payer for the transaction account rent. If not provided, `creator` is used. */
    rentPayer?: PublicKey;
    accountIndex: number;
    policyPayload: PolicyPayload;
    programId?: PublicKey;
}): VersionedTransaction;
