import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `configAuthority` and `feePayer` before sending it.
 */
export declare function setTimeLockAsAuthority({ blockhash, feePayer, settingsPda, settingsAuthority, timeLock, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    timeLock: number;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
