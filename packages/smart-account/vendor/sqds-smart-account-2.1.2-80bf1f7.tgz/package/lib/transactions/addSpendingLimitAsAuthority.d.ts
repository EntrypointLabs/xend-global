import { PublicKey, VersionedTransaction } from "@solana/web3.js";
import { Period } from "../generated";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `configAuthority`, `rent_payer` and `feePayer` before sending it.
 */
export declare function addSpendingLimitAsAuthority({ blockhash, feePayer, settingsPda, settingsAuthority, spendingLimit, rentPayer, seed, accountIndex, mint, amount, period, signers, destinations, memo, programId, expiration, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    rentPayer: PublicKey;
    spendingLimit: PublicKey;
    seed: PublicKey;
    accountIndex: number;
    mint: PublicKey;
    amount: bigint;
    period: Period;
    signers: PublicKey[];
    destinations: PublicKey[];
    memo?: string;
    programId?: PublicKey;
    expiration?: number;
}): VersionedTransaction;
