import { PublicKey, VersionedTransaction } from "@solana/web3.js";
import { PolicyPayload } from "../generated";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by required signers and `feePayer` before sending it.
 */
export declare function executePolicyPayloadSync({ blockhash, feePayer, policy, accountIndex, numSigners, policyPayload, instruction_accounts, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    policy: PublicKey;
    accountIndex: number;
    numSigners: number;
    policyPayload: PolicyPayload;
    instruction_accounts: {
        pubkey: PublicKey;
        isWritable: boolean;
        isSigner: boolean;
    }[];
    programId?: PublicKey;
}): VersionedTransaction;
