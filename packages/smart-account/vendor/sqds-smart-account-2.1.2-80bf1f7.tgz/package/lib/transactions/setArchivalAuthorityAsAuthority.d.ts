import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `configAuthority` and `feePayer` before sending it.
 */
export declare function setArchivalAuthorityAsAuthority({ blockhash, feePayer, settingsPda, settingsAuthority, newArchivalAuthority, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    newArchivalAuthority: PublicKey | null;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
