import { AccountMeta, PublicKey, VersionedTransaction } from "@solana/web3.js";
import { SettingsAction } from "../generated";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `feePayer` before sending it.
 */
export declare function executeSettingsTransactionSync({ blockhash, feePayer, settingsPda, signers, settingsActions, memo, remainingAccounts, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    signers: PublicKey[];
    settingsActions: SettingsAction[];
    remainingAccounts?: AccountMeta[];
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
