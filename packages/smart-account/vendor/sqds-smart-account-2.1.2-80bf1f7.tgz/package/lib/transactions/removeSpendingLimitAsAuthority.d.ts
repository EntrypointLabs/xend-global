import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `configAuthority` and `feePayer` before sending it.
 */
export declare function removeSpendingLimitAsAuthority({ blockhash, feePayer, settingsPda, settingsAuthority, spendingLimit, rentCollector, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    spendingLimit: PublicKey;
    settingsAuthority: PublicKey;
    rentCollector: PublicKey;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
