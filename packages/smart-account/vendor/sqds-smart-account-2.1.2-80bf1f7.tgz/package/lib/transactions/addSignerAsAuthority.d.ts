import { PublicKey, VersionedTransaction } from "@solana/web3.js";
import { SmartAccountSigner } from "../generated";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `configAuthority` and `feePayer` before sending it.
 */
export declare function addSignerAsAuthority({ blockhash, feePayer, settingsPda, settingsAuthority, rentPayer, newSigner, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    rentPayer: PublicKey;
    newSigner: SmartAccountSigner;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
