import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `configAuthority` and `feePayer` before sending it.
 */
export declare function removeSignerAsAuthority({ blockhash, feePayer, settingsPda, settingsAuthority, oldSigner, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    oldSigner: PublicKey;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
