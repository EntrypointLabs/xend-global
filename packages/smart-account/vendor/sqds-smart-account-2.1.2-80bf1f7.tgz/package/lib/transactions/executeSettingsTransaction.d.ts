import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `creator` and `feePayer` before sending it.
 */
export declare function executeSettingsTransaction({ blockhash, feePayer, settingsPda, signer, rentPayer, transactionIndex, spendingLimits, policies, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    signer: PublicKey;
    rentPayer: PublicKey;
    /** In case the transaction adds or removes SpendingLimits, pass the array of their Pubkeys here. */
    spendingLimits?: PublicKey[];
    /** In case the transaction adds or removes Policies, pass the array of their Pubkeys here. */
    policies?: PublicKey[];
    programId?: PublicKey;
}): VersionedTransaction;
