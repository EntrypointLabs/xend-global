import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `member` and `feePayer` before sending it.
 */
export declare function createProposal({ blockhash, feePayer, settingsPda, transactionIndex, creator, rentPayer, isDraft, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    /** Member of the multisig that is creating the proposal. */
    creator: PublicKey;
    /** Payer for the proposal account rent. If not provided, `creator` is used. */
    rentPayer?: PublicKey;
    isDraft?: boolean;
    programId?: PublicKey;
}): VersionedTransaction;
