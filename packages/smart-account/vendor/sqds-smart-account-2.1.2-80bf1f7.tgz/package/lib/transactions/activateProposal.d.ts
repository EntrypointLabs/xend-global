import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `signer` and `feePayer` before sending it.
 */
export declare function activateProposal({ blockhash, feePayer, settingsPda, transactionIndex, signer, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    signer: PublicKey;
    programId?: PublicKey;
}): VersionedTransaction;
