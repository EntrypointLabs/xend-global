import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `configAuthority` and `feePayer` before sending it.
 */
export declare function setNewSettingsAuthorityAsAuthority({ blockhash, feePayer, settingsPda, settingsAuthority, newSettingsAuthority, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    newSettingsAuthority: PublicKey;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
