import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `member` and `feePayer` before sending it.
 */
export declare function approveProposal({ blockhash, feePayer, settingsPda, transactionIndex, signer, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    signer: PublicKey;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
