import { PublicKey, VersionedTransaction } from "@solana/web3.js";
export declare function closeSettingsTransaction({ blockhash, feePayer, settingsPda, transactionRentCollector, transactionIndex, programId, proposalRentCollector, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    transactionRentCollector: PublicKey;
    transactionIndex: bigint;
    programId?: PublicKey;
    proposalRentCollector?: PublicKey;
}): VersionedTransaction;
