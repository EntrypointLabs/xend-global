import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by required signers and `feePayer` before sending it.
 */
export declare function executeTransactionSyncV2({ blockhash, feePayer, settingsPda, accountIndex, numSigners, instructions: instructionBytes, instruction_accounts, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    accountIndex: number;
    numSigners: number;
    instructions: Uint8Array;
    instruction_accounts: {
        pubkey: PublicKey;
        isWritable: boolean;
        isSigner: boolean;
    }[];
    programId?: PublicKey;
}): VersionedTransaction;
