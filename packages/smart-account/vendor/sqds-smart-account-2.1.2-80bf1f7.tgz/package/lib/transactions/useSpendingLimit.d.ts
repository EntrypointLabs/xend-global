import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `member` and `feePayer` before sending it.
 */
export declare function useSpendingLimit({ blockhash, feePayer, settingsPda, signer, spendingLimit, mint, accountIndex, amount, decimals, destination, tokenProgram, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    signer: PublicKey;
    spendingLimit: PublicKey;
    /** Provide if `spendingLimit` is for an SPL token, omit if it's for SOL. */
    mint?: PublicKey;
    accountIndex: number;
    amount: number;
    decimals: number;
    destination: PublicKey;
    tokenProgram?: PublicKey;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
