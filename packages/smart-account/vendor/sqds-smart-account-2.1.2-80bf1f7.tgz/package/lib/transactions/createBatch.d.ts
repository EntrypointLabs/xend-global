import { PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `creator` and `feePayer` before sending it.
 */
export declare function createBatch({ blockhash, feePayer, settingsPda, batchIndex, creator, rentPayer, accountIndex, memo, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    batchIndex: bigint;
    /** Member of the multisig that is creating the batch. */
    creator: PublicKey;
    /** Payer for the batch account rent. If not provided, `creator` is used. */
    rentPayer?: PublicKey;
    accountIndex: number;
    memo?: string;
    programId?: PublicKey;
}): VersionedTransaction;
