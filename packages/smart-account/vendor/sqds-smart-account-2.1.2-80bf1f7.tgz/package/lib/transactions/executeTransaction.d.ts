import { Connection, PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `member` and `feePayer` before sending it.
 */
export declare function executeTransaction({ connection, blockhash, feePayer, settingsPda, transactionIndex, signer, programId, }: {
    connection: Connection;
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    signer: PublicKey;
    programId?: PublicKey;
}): Promise<VersionedTransaction>;
