import { PublicKey, VersionedTransaction, AccountMeta } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `member` and `feePayer` before sending it.
 */
export declare function executePolicyTransaction({ blockhash, feePayer, policy, transactionIndex, signer, anchorRemainingAccounts, programId, }: {
    blockhash: string;
    feePayer: PublicKey;
    policy: PublicKey;
    transactionIndex: bigint;
    signer: PublicKey;
    anchorRemainingAccounts: AccountMeta[];
    programId?: PublicKey;
}): VersionedTransaction;
