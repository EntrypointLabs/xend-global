import { PublicKey, VersionedTransaction } from "@solana/web3.js";
export declare function closeEmptyPolicyTransaction({ blockhash, feePayer, emptyPolicy, transactionRentCollector, transactionIndex, programId, proposalRentCollector, }: {
    blockhash: string;
    feePayer: PublicKey;
    emptyPolicy: PublicKey;
    transactionRentCollector: PublicKey;
    transactionIndex: bigint;
    programId?: PublicKey;
    proposalRentCollector?: PublicKey;
}): VersionedTransaction;
