import { Connection, PublicKey, VersionedTransaction } from "@solana/web3.js";
/**
 * Returns unsigned `VersionedTransaction` that needs to be
 * signed by `creator` and `feePayer` before sending it.
 */
export declare function executeBatchTransaction({ connection, blockhash, feePayer, settingsPda, signer, batchIndex, transactionIndex, programId, }: {
    connection: Connection;
    blockhash: string;
    feePayer: PublicKey;
    settingsPda: PublicKey;
    signer: PublicKey;
    batchIndex: bigint;
    transactionIndex: number;
    programId?: PublicKey;
}): Promise<VersionedTransaction>;
