import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
import { SmartAccountSigner } from "../generated";
/** Add a member/key to the multisig and reallocate space if necessary. */
export declare function addSignerAsAuthority({ connection, feePayer, settingsPda, settingsAuthority, rentPayer, newSigner, memo, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    rentPayer: Signer;
    newSigner: SmartAccountSigner;
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
