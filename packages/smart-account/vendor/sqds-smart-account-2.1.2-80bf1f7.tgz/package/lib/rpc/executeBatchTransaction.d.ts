import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/** Execute a transaction from a batch. */
export declare function executeBatchTransaction({ connection, feePayer, settingsPda, signer, batchIndex, transactionIndex, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    signer: Signer;
    batchIndex: bigint;
    transactionIndex: number;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
