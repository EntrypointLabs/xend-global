import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/**
 * Create a new spending limit for the controlled multisig.
 */
export declare function removeSpendingLimitAsAuthority({ connection, feePayer, settingsPda, settingsAuthority, spendingLimit, rentCollector, memo, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    spendingLimit: PublicKey;
    rentCollector: PublicKey;
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
