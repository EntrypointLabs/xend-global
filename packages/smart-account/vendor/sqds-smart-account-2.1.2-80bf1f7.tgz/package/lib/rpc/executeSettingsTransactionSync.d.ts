import { AccountMeta, Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
import { SettingsAction } from "../generated";
/**
 * Synchronously execute configuration changes for the multisig.
 */
export declare function executeSettingsTransactionSync({ connection, feePayer, settingsPda, actions, memo, signers, remainingAccounts, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    actions: SettingsAction[];
    signers: Signer[];
    remainingAccounts?: AccountMeta[];
    memo?: string;
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
