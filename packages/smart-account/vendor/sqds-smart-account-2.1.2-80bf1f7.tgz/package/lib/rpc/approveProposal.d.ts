import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
export declare function approveProposal({ connection, feePayer, signer, settingsPda, transactionIndex, memo, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    signer: Signer;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    memo?: string;
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
