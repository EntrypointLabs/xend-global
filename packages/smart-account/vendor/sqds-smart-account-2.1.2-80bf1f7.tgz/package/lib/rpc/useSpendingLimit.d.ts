import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
export declare function useSpendingLimit({ connection, feePayer, signer, settingsPda, spendingLimit, mint, accountIndex, amount, decimals, destination, tokenProgram, memo, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    signer: Signer;
    settingsPda: PublicKey;
    spendingLimit: PublicKey;
    /** Provide if `spendingLimit` is for an SPL token, omit if it's for SOL. */
    mint?: PublicKey;
    accountIndex: number;
    amount: number;
    decimals: number;
    destination: PublicKey;
    tokenProgram?: PublicKey;
    memo?: string;
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
