import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/** Cancel a config transaction on behalf of the `member`. */
export declare function cancelProposal({ connection, feePayer, signer, settingsPda, transactionIndex, memo, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    signer: Signer;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    memo?: string;
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
