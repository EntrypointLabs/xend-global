import { AddressLookupTableAccount, Connection, PublicKey, SendOptions, Signer, TransactionMessage, TransactionSignature } from "@solana/web3.js";
/** Create a new vault transaction. */
export declare function createTransaction({ connection, feePayer, settingsPda, transactionIndex, creator, rentPayer, accountIndex, ephemeralSigners, transactionMessage, addressLookupTableAccounts, memo, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    /** Member of the multisig that is creating the transaction. */
    creator: PublicKey;
    /** Payer for the transaction account rent. If not provided, `creator` is used. */
    rentPayer?: PublicKey;
    accountIndex: number;
    /** Number of ephemeral signing PDAs required by the transaction. */
    ephemeralSigners: number;
    /** Transaction message to wrap into a multisig transaction. */
    transactionMessage: TransactionMessage;
    /** `AddressLookupTableAccount`s referenced in `transaction_message`. */
    addressLookupTableAccounts?: AddressLookupTableAccount[];
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
