import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/**
 * Close the Proposal and ConfigTransaction accounts associated with a config transaction.
 */
export declare function closeSettingsTransaction({ connection, feePayer, settingsPda, transactionRentCollector, transactionIndex, sendOptions, programId, proposalRentCollector, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    transactionRentCollector: PublicKey;
    transactionIndex: bigint;
    sendOptions?: SendOptions;
    programId?: PublicKey;
    proposalRentCollector?: PublicKey;
}): Promise<TransactionSignature>;
