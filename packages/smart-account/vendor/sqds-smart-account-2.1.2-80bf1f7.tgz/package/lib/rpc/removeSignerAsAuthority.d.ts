import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/** Add a member/key to the multisig and reallocate space if necessary. */
export declare function removeSignerAsAuthority({ connection, feePayer, settingsPda, settingsAuthority, oldSigner, memo, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    oldSigner: PublicKey;
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
