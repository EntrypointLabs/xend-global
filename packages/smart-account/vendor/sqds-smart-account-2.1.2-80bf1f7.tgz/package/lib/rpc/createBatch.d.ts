import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/** Create a new vault transactions batch. */
export declare function createBatch({ connection, feePayer, settingsPda, batchIndex, creator, rentPayer, accountIndex, memo, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    batchIndex: bigint;
    /** Member of the multisig that is creating the batch. */
    creator: Signer;
    /** Payer for the batch account rent. If not provided, `creator` is used. */
    rentPayer?: Signer;
    accountIndex: number;
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
