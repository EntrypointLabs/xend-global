import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
export declare function createProposal({ connection, feePayer, creator, rentPayer, settingsPda, transactionIndex, isDraft, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    /** Member of the multisig that is creating the proposal. */
    creator: Signer;
    /** Payer for the proposal account rent. If not provided, `creator` is used. */
    rentPayer?: Signer;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    isDraft?: boolean;
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
