import { Connection, PublicKey, SendOptions, Signer, TransactionSignature, AccountMeta } from "@solana/web3.js";
/**
 *  Execute the policy transaction.
 *  The transaction must be `ExecuteReady`.
 */
export declare function executePolicyTransaction({ connection, feePayer, policy, transactionIndex, signer, anchorRemainingAccounts, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    policy: PublicKey;
    transactionIndex: bigint;
    signer: PublicKey;
    anchorRemainingAccounts: AccountMeta[];
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
