import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/** Execute a settings transaction. */
export declare function executeSettingsTransaction({ connection, feePayer, settingsPda, transactionIndex, signer, rentPayer, spendingLimits, policies, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    signer: Signer;
    rentPayer: Signer;
    /** In case the transaction adds or removes SpendingLimits, pass the array of their Pubkeys here. */
    spendingLimits?: PublicKey[];
    /** In case the transaction adds or removes Policies, pass the array of their Pubkeys here. */
    policies?: PublicKey[];
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
