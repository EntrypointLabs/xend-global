import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
export declare function activateProposal({ connection, feePayer, signer, settingsPda, transactionIndex, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    signer: Signer;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
