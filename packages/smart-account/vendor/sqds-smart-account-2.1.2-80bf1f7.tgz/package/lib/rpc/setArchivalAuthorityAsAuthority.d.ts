import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/** Set the smart account `archival_authority`. */
export declare function setArchivalAuthorityAsAuthority({ connection, feePayer, settingsPda, settingsAuthority, newArchivalAuthority, memo, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    newArchivalAuthority: PublicKey | null;
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
