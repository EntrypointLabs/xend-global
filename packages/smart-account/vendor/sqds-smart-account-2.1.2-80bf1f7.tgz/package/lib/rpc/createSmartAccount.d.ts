import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
import { SmartAccountSigner } from "../generated";
/** Creates a new multisig. */
export declare function createSmartAccount({ connection, treasury, creator, settings, settingsAuthority, threshold, signers, timeLock, rentCollector, memo, sendOptions, programId, }: {
    connection: Connection;
    treasury: PublicKey;
    creator: Signer;
    settings: PublicKey;
    settingsAuthority: PublicKey | null;
    threshold: number;
    signers: SmartAccountSigner[];
    timeLock: number;
    rentCollector: PublicKey | null;
    memo?: string;
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
