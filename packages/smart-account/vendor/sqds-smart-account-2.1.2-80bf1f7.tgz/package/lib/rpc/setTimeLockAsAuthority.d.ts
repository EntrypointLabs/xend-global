import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/** Set the `time_lock` config parameter for the multisig. */
export declare function setTimeLockAsAuthority({ connection, feePayer, settingsPda, settingsAuthority, timeLock, memo, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    timeLock: number;
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
