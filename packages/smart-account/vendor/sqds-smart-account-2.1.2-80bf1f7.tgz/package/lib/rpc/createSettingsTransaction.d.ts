import { AccountMeta, Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
import { SettingsAction } from "../generated";
/** Create a new settings transaction. */
export declare function createSettingsTransaction({ connection, feePayer, settingsPda, transactionIndex, creator, rentPayer, actions, memo, signers, sendOptions, remainingAccounts, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    /** Member of the multisig that is creating the transaction. */
    creator: PublicKey;
    /** Payer for the transaction account rent. If not provided, `creator` is used. */
    rentPayer?: PublicKey;
    actions: SettingsAction[];
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    remainingAccounts?: AccountMeta[];
    programId?: PublicKey;
}): Promise<TransactionSignature>;
