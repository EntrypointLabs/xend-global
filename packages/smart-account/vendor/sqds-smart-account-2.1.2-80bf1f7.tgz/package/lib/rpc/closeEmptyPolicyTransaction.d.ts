import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/**
 * Close the Proposal and ConfigTransaction accounts associated with a
 * empty/deleted policy.
 */
export declare function closeEmptyPolicyTransaction({ connection, feePayer, emptyPolicy, transactionRentCollector, transactionIndex, sendOptions, programId, proposalRentCollector, }: {
    connection: Connection;
    feePayer: Signer;
    emptyPolicy: PublicKey;
    transactionRentCollector: PublicKey;
    transactionIndex: bigint;
    sendOptions?: SendOptions;
    programId?: PublicKey;
    proposalRentCollector?: PublicKey;
}): Promise<TransactionSignature>;
