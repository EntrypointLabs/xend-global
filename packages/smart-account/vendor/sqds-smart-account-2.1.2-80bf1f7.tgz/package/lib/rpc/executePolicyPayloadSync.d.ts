import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
import { PolicyPayload } from "../generated";
/**
 * Execute a policy payload synchronously with V2 instruction.
 * All required signers must be provided.
 */
export declare function executePolicyPayloadSync({ connection, feePayer, policy, accountIndex, numSigners, policyPayload, instruction_accounts, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    policy: PublicKey;
    accountIndex: number;
    numSigners: number;
    policyPayload: PolicyPayload;
    instruction_accounts: {
        pubkey: PublicKey;
        isWritable: boolean;
        isSigner: boolean;
    }[];
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
