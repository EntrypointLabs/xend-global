import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/**
 *  Execute the multisig transaction synchronously.
 *  All required signers must be provided.
 */
export declare function executeTransactionSync({ connection, feePayer, settingsPda, accountIndex, numSigners, instructions, instruction_accounts, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    accountIndex: number;
    numSigners: number;
    instructions: Uint8Array;
    instruction_accounts: {
        pubkey: PublicKey;
        isWritable: boolean;
        isSigner: boolean;
    }[];
    signers: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
