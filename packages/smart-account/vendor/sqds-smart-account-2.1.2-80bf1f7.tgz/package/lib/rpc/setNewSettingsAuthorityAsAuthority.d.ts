import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/** Set the multisig `config_authority`. */
export declare function setNewSettingsAuthorityAsAuthority({ connection, feePayer, settingsPda, settingsAuthority, newSettingsAuthority, memo, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    settingsAuthority: PublicKey;
    newSettingsAuthority: PublicKey;
    memo?: string;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
