import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
import { PolicyPayload } from "../generated";
/** Create a new vault transaction. */
export declare function createPolicyTransaction({ connection, feePayer, policy, transactionIndex, creator, rentPayer, accountIndex, policyPayload, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    policy: PublicKey;
    transactionIndex: bigint;
    /** Member of the multisig that is creating the transaction. */
    creator: PublicKey;
    /** Payer for the transaction account rent. If not provided, `creator` is used. */
    rentPayer?: PublicKey;
    accountIndex: number;
    policyPayload: PolicyPayload;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
