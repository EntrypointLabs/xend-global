import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
/**
 *  Execute the multisig transaction.
 *  The transaction must be `ExecuteReady`.
 */
export declare function executeTransaction({ connection, feePayer, settingsPda, transactionIndex, signer, signers, sendOptions, programId, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    transactionIndex: bigint;
    signer: PublicKey;
    signers?: Signer[];
    sendOptions?: SendOptions;
    programId?: PublicKey;
}): Promise<TransactionSignature>;
