import { Connection, PublicKey, SendOptions, Signer, TransactionSignature } from "@solana/web3.js";
import { Period } from "../generated";
/**
 * Create a new spending limit for the controlled multisig.
 */
export declare function addSpendingLimitAsAuthority({ connection, feePayer, settingsPda, settingsAuthority, spendingLimit, rentPayer, seed, accountIndex, mint, amount, period, destinations, memo, signers, sendOptions, programId, expiration, }: {
    connection: Connection;
    feePayer: Signer;
    settingsPda: PublicKey;
    settingsAuthority: Signer;
    spendingLimit: PublicKey;
    rentPayer: Signer;
    seed: PublicKey;
    accountIndex: number;
    mint: PublicKey;
    amount: bigint;
    period: Period;
    signers: PublicKey[];
    destinations: PublicKey[];
    memo?: string;
    sendOptions?: SendOptions;
    programId?: PublicKey;
    expiration?: number;
}): Promise<TransactionSignature>;
