import { PublicKey } from "@solana/web3.js";
export declare function getProgramConfigPda({ programId, }: {
    programId?: PublicKey;
}): [PublicKey, number];
export declare function getSettingsPda({ accountIndex, programId, }: {
    accountIndex: bigint;
    programId?: PublicKey;
}): [PublicKey, number];
export declare function getSmartAccountPda({ settingsPda, 
/** Authority index. */
accountIndex, programId, }: {
    settingsPda: PublicKey;
    accountIndex: number;
    programId?: PublicKey;
}): [PublicKey, number];
export declare function getEphemeralSignerPda({ transactionPda, ephemeralSignerIndex, programId, }: {
    transactionPda: PublicKey;
    ephemeralSignerIndex: number;
    programId?: PublicKey;
}): [PublicKey, number];
export declare function getTransactionPda({ settingsPda, transactionIndex, programId, }: {
    settingsPda: PublicKey;
    /** Transaction index. */
    transactionIndex: bigint;
    programId?: PublicKey;
}): [PublicKey, number];
export declare function getProposalPda({ settingsPda, transactionIndex, programId, }: {
    settingsPda: PublicKey;
    /** Transaction index. */
    transactionIndex: bigint;
    programId?: PublicKey;
}): [PublicKey, number];
export declare function getBatchTransactionPda({ settingsPda, batchIndex, transactionIndex, programId, }: {
    settingsPda: PublicKey;
    batchIndex: bigint;
    transactionIndex: number;
    programId?: PublicKey;
}): [PublicKey, number];
export declare function getSpendingLimitPda({ settingsPda, seed, programId, }: {
    settingsPda: PublicKey;
    seed: PublicKey;
    programId?: PublicKey;
}): [PublicKey, number];
export declare function getPolicyPda({ settingsPda, policySeed, programId, }: {
    settingsPda: PublicKey;
    policySeed: number;
    programId?: PublicKey;
}): [PublicKey, number];
